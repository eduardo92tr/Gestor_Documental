<?php
const BASE_URL = "http://localhost/gestion_php/";
const HOST = "localhost:3307";
const USER = "root";
const PASS = "";
const DB = "gestion_php";
const CHARSET = "charset=utf8";
?>